<?php 

function dd($vars)
{
    var_dump($vars);
    die;
}

function redirect($location)
{
    $location = trim('/',$location);
    header('Location:'.BASEURL.$location);
}