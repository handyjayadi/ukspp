<div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Data Kelas</h6>
                            <a class="btn btn-primary" href="<?=BASEURL?>pembayaran/createpembayaranhal">TAMBAH pembayaran</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Kelas</th>
                                            <th>Jurusan</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <?php foreach ($data['pembayaran'] as $pembayaran) { ?>
                                    
                                    <tbody>                                       
                                        <tr>
                                            
                                            <td><?= $pembayaran['tahun_ajaran'] ?></td>
                                            <td><?= $pembayaran['nominal'] ?></td>
                                            <td>
                                            <a href="<?=BASEURL;?>pembayaran/editpembayaranhal/<?= $pembayaran['id_pembayaran'];?>" class="btn btn-warning btn-icon-split"><span class="icon text-white-50"><i class="fas fa-pen"></i></span><span class="text">Edit</span></a>

                                            <a href="<?=BASEURL;?>pembayaran/hapuspembayaran/<?= $pembayaran['id_pembayaran'];?>" class="btn btn-danger btn-icon-split"><span class="icon text-white-50"><i class="fas fa-trash"></i></span><span class="text" onclick="return confirm('Hapus Data?')">Hapus</span></a>
                                            </td>
                                            
                                        </tr>
                                    </tbody>
                               <?php }?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->