<div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Create Pembayaran</h6>
                <a class="btn btn-primary" href="<?=BASEURL?>pembayaran">Kembali</a>
            </div>
                <form class="user ml-3 mr-3" method="post" action="<?=BASEURL?>pembayaran/createpembayaran">
                    <div class="form-group">
                        <label for="thnajaran">tahun ajaran</label>
                        <input type="text" name="tahunajaran"class="form-control "
                            id="thnajaran" required>
                    </div>
                    
                    <div class="form-group">
                    <label for="nominal">Nominal</label>
                        <input type="text" name="nominal"class="form-control" 
                            id="nominal" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                    
                </form>
                