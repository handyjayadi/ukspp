<div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Data Siswa</h6>
                            <a class="btn btn-primary" href="<?=BASEURL?>siswa/insertsiswa">TAMBAH SISWA</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>role</th>
                                            <th>Start date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <?php foreach ($data['siswa'] as $siswa) { ?>
                                    
                                    <tbody>                                       
                                        <tr>
                                            
                                            <td><?= $siswa['username'] ?></td>
                                            <td><?= $siswa['role'] ?></td>
                                            <td><?=$siswa['password']?></td>
                                            <td>
                                            <a href="<?=BASEURL;?>pengguna/editpengguna/<?= $siswa['id_siswa'];?>" class="btn btn-warning btn-icon-split"><span class="icon text-white-50"><i class="fas fa-pen"></i></span><span class="text">Edit</span></a>

                                            <a href="<?=BASEURL;?>pengguna/hapususer/<?= $mhs['id_siswa'];?>" class="btn btn-danger btn-icon-split"><span class="icon text-white-50"><i class="fas fa-trash"></i></span><span class="text" onclick="return confirm('Hapus Data?')">Hapus</span></a>
                                            </td>
                                            
                                        </tr>
                                    </tbody>
                               <?php }?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->