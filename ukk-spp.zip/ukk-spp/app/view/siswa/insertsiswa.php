
<div class="card-header py-3 d-flex justify-content-between">
    <h6 class="m-0 font-weight-bold text-primary">Create Siswa</h6>
</div>
<form class="user ml-5 mr-5 justify-content-start" method="post" action="<?=BASEURL?>pengguna/updateuser">
    <div class="form-group">
        <label for="username">Username</label>
        <input type="hidden" name="username" class="form-control"  required>

        <label for="username">Username</label>
        <input type="text" name="username" class="form-control"  required>

        <label for="nama">nama</label>
        <input type="text" name="nama" class="form-control"  required>

        <label for="telefon">telefon</label>
        <input type="text" name="telefon" class="form-control"  required>

        <label for="alamat">alamat</label>
        <input type="text" name="alamat" class="form-control"  required>

        <label for="nis">nis</label>
        <input type="text" name="nis" class="form-control"  required>

        <label for="nisn">nisn</label>
        <input type="text" name="nisn" class="form-control"  required>
        
        <label for="kelas">kelas</label>
        <select class="form-control" name="kelas" id="">
            <?php foreach ($data['kelas'] as $kelas) { ?>
                 <option class="form-control"value="<?= $kelas['nama']?>"><?=$kelas['nama']?> <?= $kelas['kompetensi_keahlian'] ?></option>
            <?php } ?>
        </select>

        <label for="kelas">kelas</label>
        <select class="form-control" name="kelas" id="">
            <?php foreach ($data['kelas'] as $kelas) { ?>
                 <option class="form-control"value="<?= $kelas['nama']?>"><?=$kelas['nama']?> <?= $kelas['kompetensi_keahlian'] ?></option>
            <?php } ?>
        </select>

        <label for="kelas">kelas</label>
        <select class="form-control" name="kelas" id="">
            <?php foreach ($data['kelas'] as $kelas) { ?>
                 <option class="form-control"value="<?= $kelas['nama']?>"><?=$kelas['nama']?> <?= $kelas['kompetensi_keahlian'] ?></option>
            <?php } ?>
        </select>
        

        <label for="password">password</label>
        <input type="password" name="password" class="form-control"  required>


        

    </div>
    <button type="submit" class="btn btn-primary btn-block">Simpan</button>
</form>