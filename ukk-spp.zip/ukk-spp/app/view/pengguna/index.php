
<div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Data Siswa</h6>
                            <a class="btn btn-primary" data-toggle="modal" data-target="#tambahpengguna" >TAMBAH</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Username</th>
                                            <th>role</th>
                                            <th>Start date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <?php foreach ($data['user'] as $mhs) { ?>
                                    
                                    <tbody>                                       
                                        <tr>
                                            
                                            <td><?= $mhs['username'] ?></td>
                                            <td><?= $mhs['role'] ?></td>
                                            <td><?=$mhs['password']?></td>
                                            <td>
                                            <a href="<?=BASEURL;?>pengguna/editpengguna/<?= $mhs['id_pengguna'];?>" class="btn btn-warning btn-icon-split"><span class="icon text-white-50"><i class="fas fa-pen"></i></span><span class="text">Edit</span></a>

                                            <a href="<?=BASEURL;?>pengguna/hapususer/<?= $mhs['id_pengguna'];?>" class="btn btn-danger btn-icon-split"><span class="icon text-white-50"><i class="fas fa-trash"></i></span><span class="text" onclick="return confirm('Hapus Data?')">Hapus</span></a>
                                            </td>
                                            
                                        </tr>
                                    </tbody>
                               <?php }?>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

    <div class="modal fade" id="tambahpengguna" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Pengguna</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form class="user ml-3 mr-3" method="post" action="<?=BASEURL?>pengguna/tambahpengguna">
                    <div class="form-group">
                        <label for="exampleInputEmail">Username</label>
                        <input type="text" name="username"class="form-control "
                            id="exampleInputEmail" aria-describedby="emailHelp"required>
                    </div>
                    <div class="form-group">
                    <label for="exampleInputPassword">Password</label>
                        <input type="password" name="password"class="form-control" 
                            id="exampleInputPassword"required>
                    </div>
                    <div class="form-group">
                    <label for="password2">Password</label>
                        <input type="password" name="password2"class="form-control" 
                            id="password2" required>
                    </div>
                    <div class="form-group">
                        <select name="role" id="" class="form-control">
                            <option value="1">Admin</option>
                            <option value="2">Petugas</option>
                            <option value="3" selected>Siswa</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                </form>
                <div class="modal-footer">                  
                </div>
            </div>
        </div>
    </div>

   