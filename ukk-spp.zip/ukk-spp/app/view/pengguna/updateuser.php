<form class="user ml-3 mr-3" method="post" action="<?=BASEURL?>pengguna/updateuser">
                    <div class="form-group">
                        <label for="exampleInputEmail">Username</label>
                        <input type="hidden" name="id_pengguna" value="<?=$data['user']['id_pengguna']?>">
                        <input type="text" name="username"class="form-control "
                            id="exampleInputEmail" aria-describedby="emailHelp" value="<?= $data['user']['username']; ?>" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Simpan</button>
                </form>