<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
        </div>
        <div class="sidebar-brand-text mx-3">SPP</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?=BASEURL?>home">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Interface
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <?php if ($_SESSION['user']['role']== 1) {?>
        <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <span>Pengguna</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?=BASEURL?>pengguna">user</a>
                <a class="collapse-item" href="<?=BASEURL?>siswa">siswa</a>
                <a class="collapse-item" href="<?=BASEURL?>petugas">petugas</a>
            </div>
        </div>
    </li>
    <?php }?>


    <li class="nav-item">
    <a class="nav-link collapsed" href="<?=BASEURL?>kelas">
        <span>kelas</span>
    </a>  
    </li>      

    <li class="nav-item">
    <a class="nav-link collapsed" href="<?=BASEURL?>pembayaran">
        <span>Pembayaran</span>
    </a>  
    </li>   

    

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    

</ul>
<!-- End of Sidebar -->