<div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Create Kelas</h6>
                            <a class="btn btn-primary" href="<?=BASEURL?>kelas">Kembali</a>
                        </div>
                <form class="user ml-3 mr-3" method="post" action="<?=BASEURL?>kelas/storekelas">
                    <div class="form-group">
                        <label for="exampleInputEmail">Kelas</label>
                        <input type="text" name="namakelas"class="form-control "
                            id="exampleInputEmail" aria-describedby="emailHelp"required>
                    </div>
                    
                    <div class="form-group">
                    <label for="jurusan">Jurusan</label>
                        <input type="text" name="jurusan"class="form-control" 
                            id="password2" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                    
                </form>
                