<div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Data Kelas</h6>
                            <a class="btn btn-primary" href="<?=BASEURL?>kelas">Kembali</a>
                        </div>
                <form class="user ml-3 mr-3" method="post" action="<?=BASEURL?>kelas/editkelass">

                <input type="hidden" name="id" class="form-control "
                            id="exampleInputEmail" aria-describedby="emailHelp" value="<?=$data['kelas']['id_kelas']?>">
                    <div class="form-group">
                        <label for="exampleInputEmail">Kelas</label>
                        <input type="text" name="nama" class="form-control "id="exampleInputEmail" aria-describedby="emailHelp" value="<?=$data['kelas']['nama']?>">
                    </div>
                    
                    <div class="form-group">
                    <label for="jurusan">Jurusan</label>
                        <input type="text" name="kompetensi_keahlian"class="form-control" id="password2" value="<?=$data['kelas']['kompetensi_keahlian']?>">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Tambah</button>
                    
                </form>
                